#ifndef HOSTAPI_HPP
#define HOSTAPI_HPP

struct HostAPI
{
    public:
        const ILogger* logger;
};

#endif // HOSTAPI_HPP
