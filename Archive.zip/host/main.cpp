#include <iostream>

int main()
{
    std::cout << "foo thy bar" << std::endl;
}
